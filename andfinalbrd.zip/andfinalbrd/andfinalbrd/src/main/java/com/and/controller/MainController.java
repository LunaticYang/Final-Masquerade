package com.and.controller;

import java.security.Principal;
import java.util.List;

import javax.validation.Valid;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.and.model.Customer;
import com.and.model.User;
import com.and.service.CustomerService;
import com.and.service.UserService;
import com.and.service.ValidationService;





/********************************************************           
 * MainController --Handling  Requests                  *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Handles Authenticated User Request          *   
 *                                                      *   
 * Usage:  Dispatch Page Request                        *   
 *      		                                        *   
 ********************************************************/  




@Controller
public class MainController 
{

	//Logger to MainController
	final static Logger log = Logger.getLogger(MainController.class.getName());




	@Autowired
	CustomerService customerService;


	@Autowired
	ValidationService validationService;


	@Autowired
	UserService userService;





//USER SCREEN
//============================================================================================================


	// Load UserScreen -----------------
	@RequestMapping(value = "/split")
	public String ShowCustomerHomePage() 
	{
		return "Split";
	}

	





//ADD RECORDS
//-------------------------------------------------------------------------------------------------------




	//Add Record------------------------------------------
	//Load New Record Form--------------------------------
	@RequestMapping("/addCustomer")
	public ModelAndView ShowCustomerForm(Customer customer) 
	{
		log.info("Loading New Customer Form");
		return new ModelAndView("NewCustomerDetails");

	}



	//Add Record To DataBase
	@RequestMapping("/newCustomer")
	public ModelAndView addnewUser(@Valid @ModelAttribute(value="customer") Customer customer, BindingResult result,Principal p) {
		if(result.hasErrors())
		{
			return new ModelAndView("NewCustomerDetails");
		}
		
		log.info("Got Customer Details From UI");
		int cCode = customer.getCustomerCode();
		
		Customer cust = customerService.viewCustomer(cCode);
		
		if (cust != null) 
		{
		  log.info("Checking if Customer Exists");
		  return new ModelAndView("NewCustomerDetails", "error","Customer with this Code Already Exists");
		}


		customer.setCreatedBy(p.getName());
		log.info("Customer Added Successfully");
		customerService.addcustomer(customer);
		return new ModelAndView("NewCustomerDetails", "success","Customer was Added SuccessFully"); //
		

	}




//VIEW - ALL CUSTOMER RECORDS
//-----------------------------------------------------------------------------------------------------------------






	//View Records-------------------------------------------------
	@RequestMapping(value = "/viewall", method = RequestMethod.GET)
	public String viewAllUsers(Model model) 
	{
		log.info("Request For View All Customers");
		List<Customer> customer = customerService.viewAll();

		model.addAttribute("customer", customer);
		log.info("Displaying All Customers");
		return "viewAll"; 

	}







//VIEW - BY CODE
//-----------------------------------------------------------------------------------------------------------------





	//View Record by Code
	@RequestMapping(value = "/viewCustomer", method = RequestMethod.GET)
	public String getCodeForSingleView() 
	{
		log.info("Request For single View BY Code");
		return "singleviewload";

	}


	//View Record by code
	@RequestMapping(value = "/oneview", method = RequestMethod.POST)
	public ModelAndView oneview(Model model,@RequestParam("customerCode") String customerCode) 
	{

		int flag = validationService.validateCustomerCode(customerCode);
		if (flag == 2) 
		{
			log.error("Customer Code was Not Inserted");
			return new ModelAndView("singleviewload", "error","You Must Enter Customer Code");
		}



		Customer customer = customerService.viewCustomer(Integer.parseInt(customerCode));
		
		model.addAttribute("customer", customer);
		

		if (customer != null) 
		{
			log.info("Displaying Customer");
			return new ModelAndView("singleViewDisplay");
		} 

		else 

		{
			log.fatal("Customer With that Code Not found");
			return new ModelAndView("singleviewload", "error",
					"No Customer Found With that code");
		}

	}








//VIEW- BY NAME
//-----------------------------------------------------------------------------------------------------------------





	//View Record By Name ---------------------------------------------------

	@RequestMapping(value = "/viewByName", method = RequestMethod.GET)
	public String viewByName() 
	{
		log.info("Request for Displaying Customers By names");
		return "LoadCustomerName";
	}



	@RequestMapping(value = "/viewByInputName", method = RequestMethod.POST)
	public ModelAndView viewByInputName(Model model,@RequestParam("customerName") String customerName, @ModelAttribute Customer customer) 
	{
		log.info("Loading list Of Customers By That name");
		List<Customer> cust = null;
		cust = customerService.viewCustomersByName(customerName);

		if (cust.size() > 0) 
		{
			log.info("Displaying Customers");
			model.addAttribute("customer", cust);
			return new ModelAndView("viewByName");
		} 

		else 
		{
			log.fatal("No Customers Found");
			return new ModelAndView("LoadCustomerName", "error","No Customer Found With That name.");
		}

	}








//UPDATE
//-----------------------------------------------------------------------------------------------------------------







	//Update Customer Record by Code
	@RequestMapping(value = "/update", method = RequestMethod.GET)
	public String updateUser() 
	{
		log.info("Request To Update customer");
		return "updateCustomerLoad";

	}



	@RequestMapping(value = "/updatevalue", method = RequestMethod.POST)
	public ModelAndView updateValue(Model model,@RequestParam("customerCode") String customerCode, @ModelAttribute Customer customer) 
	{

		log.info("Getting Code from customer");
		customer = customerService.viewCustomer(Integer.parseInt(customerCode));

		int flag = validationService.validateCustomerCode(customerCode);
		
		if (flag == 2) 
		{
			log.error("customer code was not inserted");
			return new ModelAndView("updateCustomerLoad", "error","Enter Customer code");
		}



		model.addAttribute("customer", customer);
		if (customer != null) 
		{
			log.info("Updating customer");
			return new ModelAndView("UpdateCustomer");
		} 

		else 

		{
			log.error("Customer was Not found");
			return new ModelAndView("updateCustomerLoad", "error","No Customer Could Be Found By That Code");
		}
	}



	//Update the Selected Record
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	public ModelAndView updated(@Valid @ModelAttribute(value="customer")Customer customer, BindingResult result) {
		
		if(result.hasErrors())
		{
			return new ModelAndView("UpdateCustomer");
		}


		customerService.updateCustomer(customer);
		log.info("Updated Successfully");
		return new ModelAndView("UpdateCustomer", "success","Updation was successful");

		}






//DELETE
//-----------------------------------------------------------------------------------------------------------------




	//Delete Record------------------------------------------------------
	@RequestMapping(value = "/deleteCustomer", method = RequestMethod.GET)
	public String getCodeToDelete() 
	{
	
		log.info("Getting Form For Taking Customer Code To Delete");
		return "DeleteView";
	}




	//Delete Selected Record
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	public ModelAndView delete(Model model,@RequestParam("customerCode") String customerCode) 
	{

		int custCode = Integer.parseInt(customerCode);

		int flag = validationService.validateCustomerCode(customerCode);
		
		if (flag == 1) 
		{
			log.info("Checking If Customer Exists");
			return new ModelAndView("DeleteView", "success","Customer Does Not Exist");
												
		} 

		else if (flag == 2) 
		{
			log.error("Custoemr Code was not inputted");
			return new ModelAndView("DeleteView", "success","Enter Customer Code");
		} 

		else 

		{
			customerService.deleteCustomer(custCode);
			log.info("SuccessFully Deleted");
			return new ModelAndView("DeleteView", "success",
					"Customer was Deleted Successfully");
		}

	}





//-----------------------------------------------------------------------------------------------------------------
//-----------------------------------------------------------------------------------------------------------------






//ADMIN SCREEN CONTROL
//============================================================================================================


	

	//ADMIN Screen Display	
	@RequestMapping(value = "/User")
	// load userpage
	public String loadUser() 
	{
		return "SplitUser";
	}



//-----------------------------------------------------------------------------------------------------------------






	//Add New User-------------------------
	@RequestMapping("/adduser")
	public ModelAndView addUser(User user) 
	{
		log.info("Request To Add NEw User");
		return new ModelAndView("NewUser"); 
	}

	


	//Adding New User------------------------------------------------------
	@RequestMapping("/newUser")
	public ModelAndView addnewUser(@Valid @ModelAttribute("user")User user) 
	{
		log.info("Getting User Details");
		userService.adduser(user);
		log.info("User Added");
		return new ModelAndView("NewUser", "message", "User Was ADDED");

	}






//-----------------------------------------------------------------------------------------------------------------







	//Delete Existing Authenticated User
	@RequestMapping(value = "/deleteUser", method = RequestMethod.GET)
	public String deleteuser() 
	{

		return "getUserCode";

	}

	
	//Delete  Selected User
	@RequestMapping(value = "/deleteUser", method = RequestMethod.POST)
	public String deleteUser(Model model, @RequestParam("id") String id) 
	{
		userService.deleteUser(Integer.parseInt(id));
		return "DeleteView";
	}







//-----------------------------------------------------------------------------------------------------------------







	//View All Authenticated Users
	@RequestMapping(value = "/viewallUser", method = RequestMethod.GET)
	public String viewAll(Model model) 
	{
		log.info("request To View All");
		List<User> user = userService.viewAllUser();

		model.addAttribute("user", user);
		log.info("Displaying All");
		return "viewAllUser";

	}





//-----------------------------------------------------------------------------------------------------------------



	//Optional Right
	//View All Records From User Screen------------------------------------ 
	@RequestMapping(value = "/viewallCustomer", method = RequestMethod.GET)
	public String viewallCustomer(Model model) 
	{

		List<Customer> customer = customerService.viewAll();
		log.info("Admin Views All Customers");

		model.addAttribute("customer", customer);

		return "viewAll";

	}

}
