package com.and.service;





/********************************************************           
 * CustomerServiceImpl --Implements CustomerService     *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Provide CRUD Services                       *   
 *                                                      *   
 * Usage:  Crud Services are performed                  *   
 *             							                *   
 ********************************************************/  




import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.and.dao.CustomerDao;
import com.and.model.Customer;



@Service 
public class CustomerServiceImpl implements CustomerService 
{
		
		final static Logger log = Logger.getLogger(CustomerServiceImpl.class.getName());
		@Autowired
		CustomerDao customerDao;







//SERVICE: ADD RECORD
		@Transactional 
		public Customer addcustomer(Customer customer) 
		{
	    	
	    	log.info("In service layer");
	    	log.info("Calling add Customer dao");
			customerDao.addCustomer(customer);
			return customer;
		}






//SERVICE: VIEW RECORDS
		@Transactional
		public List<Customer> viewAll() 
		{
			log.info("In service layer");
		    log.info("Calling get all customer  dao");
			return customerDao.getAllCustomers();
		}



//SERVICE: VIEW BY CODE 
		@Transactional
		public Customer viewCustomer(int customerCode) 
		{
			log.info("In service layer");
		    log.info("Calling get Customer by code dao");

			return customerDao.viewCustomerByCode(customerCode);
		}




//SERVICE: VIEW BY NAME
		public List<Customer> viewCustomersByName(String customerName) 
		{ 
			log.info("In service layer");
		    log.info("Calling get all Customer by name dao");
			return customerDao.getAllCustomersByName(customerName);
		}








//SERVICE: UPDATE RECORD
		@Transactional
		public Customer updateCustomer(Customer customer) 
		{
			log.info("In service layer");
		    log.info("Calling update Customer by code dao");
			return customerDao.updateCustomer(customer);
		}
	



	
//SERVICE: DELETE RECORD 
	@Transactional
	public void deleteCustomer(int customerCode) 
	{
		log.info("In service layer");
	    log.info("Calling Delete customer dao");
		customerDao.deleteCustomer(customerCode);

	}
	

}
