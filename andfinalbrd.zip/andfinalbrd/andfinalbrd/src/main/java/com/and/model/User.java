package com.and.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.validator.constraints.NotEmpty;








/********************************************************           
 * USER  --POJO class for User		                	*   
 *                                                      *   
 * Author:  NIKHIL GUPTA	                            *   
 *                                                      *   
 * Purpose: To Store All User Related Data          	*   
 *                                                      *   
 * Usage:                                               *   
 *     works As class to store All the data of User 	*   
 ********************************************************/ 







@Entity
@Table(name = "anand_user0021")
public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	private int id;
	@Column(name = "userName")
	@NotEmpty
	private String username;
	@Column(name = "password")
	@NotEmpty
	private String password;
	@Column(name = "enabled")
	@NotEmpty
	private int enabled;

	@ManyToOne(cascade = CascadeType.ALL)
	
	private Role role;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Role getRole() {
		return role;
	}

	public void setRole(Role role) {
		this.role = role;
	}

	public int getEnabled() {
		return enabled;
	}

	public void setEnabled(int enabled) {
		this.enabled = enabled;
	}

	public User() {

	}
	

	public User(int id, String username, String password, int enabled, Role role) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.enabled = enabled;
		this.role = role;
	}

	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", password="
				+ password + ", enabled=" + enabled + ", role=" + role + "]";
	}

}
