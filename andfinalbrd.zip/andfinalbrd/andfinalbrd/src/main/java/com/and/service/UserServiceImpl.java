package com.and.service;





/********************************************************           
 * CustomerServiceImpl --Implements UserService         *   
 *                                                      *   
 * Author:  NIKHIL GUPTA                                *   
 *                                                      *   
 * Purpose: Provide CRUD Services                       *   
 *                                                      *   
 * Usage:  Crud Services are performed                  *   
 *             							                *   
 ********************************************************/   







import java.util.List;

import javax.transaction.Transactional;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.and.dao.UserDao;
import com.and.model.User;



@Service
public class UserServiceImpl implements UserService 
{



	@Autowired
	UserDao userDao;


	//Logger
	final static Logger log = Logger.getLogger(UserServiceImpl.class.getName());
	






//SERVICE: ADD USER
	@Transactional
	public User adduser(User user) 

	{ 
		EncodingPassword encode = new EncodingPassword();
		log.info("In service layer");
	    log.info("Encrypting Password");
	    log.info("calling dao to add User/admin");
		encode.encryptPass(user);
		userDao.addUser(user);
		return user;
	}
	




//SERVICE: VIEW USERS
	@Transactional
	public List<User> viewAllUser() 
	{

		log.info("In service layer");
	    log.info("Calling View All user dao");
		return userDao.getAllUser();
	
	}







//SERVICE: DELETE USER
	@Transactional
	public void deleteUser(int id) 
	{ 
	
		log.info("In service layer");
	    log.info("Calling Delete User dao");
		userDao.deleteUser(id);

	}
	

}
