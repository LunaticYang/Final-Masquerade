package com.nucleus.nsbt.brd4.spring.config;


import java.beans.PropertyVetoException;
import java.util.Properties;
import java.util.logging.Logger;

import javax.sql.DataSource;

import org.apache.commons.dbcp.BasicDataSource;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

import com.mchange.v2.c3p0.ComboPooledDataSource;



@Configuration
@EnableWebMvc
@ComponentScan(basePackages="com.nucleus.nsbt.brd4.spring")
@PropertySource("classpath:persistence-mysql.properties")
public class AppConfig 
{

	
	//holds prop's
	@Autowired
	private Environment env;
	
	// set up a logger for diagnostics
	
	private Logger logger = Logger.getLogger(getClass().getName());
	
	
	//ViewResolver

	@Bean
	public ViewResolver viewResolver() 
	{
		
		InternalResourceViewResolver viewResolver = new InternalResourceViewResolver();
		
		viewResolver.setPrefix("/WEB-INF/view/");
		viewResolver.setSuffix(".jsp");
		
		return viewResolver;
	}
	
	
	
	
	
	// define a bean for security datasource
	
		@Bean
		public DataSource securityDataSource() 
		{
			
			// create connection pool
			ComboPooledDataSource securityDataSource = new ComboPooledDataSource();
			
			
			
			// set the jdbc driver class
			
			try 
			{
				securityDataSource.setDriverClass(env.getProperty("jdbc.driver"));
			} 
			catch (PropertyVetoException exc) 
			{
				throw new RuntimeException(exc);
			}
			
			
			logger.info(">>> jdbc.url=" + env.getProperty("jdbc.url"));
			logger.info(">>> jdbc.user=" + env.getProperty("jdbc.user"));
			
			
			
			
			// set database connection props
			
			securityDataSource.setJdbcUrl(env.getProperty("jdbc.url"));
			securityDataSource.setUser(env.getProperty("jdbc.user"));
			securityDataSource.setPassword(env.getProperty("jdbc.password"));
			
			
			
			// set connection pool props
			
			securityDataSource.setInitialPoolSize(getIntProperty("connection.pool.initialPoolSize"));

			securityDataSource.setMinPoolSize(getIntProperty("connection.pool.minPoolSize"));

			securityDataSource.setMaxPoolSize(getIntProperty("connection.pool.maxPoolSize"));

			securityDataSource.setMaxIdleTime(getIntProperty("connection.pool.maxIdleTime"));
			
			return securityDataSource;
		}
		
		
		
		
		// read env to int
		
		private int getIntProperty(String propName) 
		{
			
			return Integer.parseInt(env.getProperty(propName));
		}
	
	
	/*@Bean
	public DataSource dataSource()
	{
		BasicDataSource dataSource = new BasicDataSource();
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@10.1.50.198:1521:orcl");
		dataSource.setUsername("sh");
		dataSource.setPassword("sh");

		return dataSource;
	}
	
	
	@Bean
	public SessionFactory sessionFactory(DataSource dataSource) 
	{
		LocalSessionFactoryBuilder builder = new LocalSessionFactoryBuilder(dataSource);
		
		Properties props = new Properties();
		props.put("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
		props.put("hibernate.show_sql", "true");
		props.put("hibernate.hbm2ddl.auto", "update");
		
		builder.addProperties(props);
		//builder.addAnnotatedClass(Customer.class);
		builder.addAnnotatedClass(User.class);
		builder.addAnnotatedClass(Role.class);
		
		return builder.buildSessionFactory();
	}
	
	@Bean
	public HibernateTransactionManager manager(SessionFactory sessionFactory) 
	{
		HibernateTransactionManager transactionManager = new HibernateTransactionManager();
		transactionManager.setSessionFactory(sessionFactory);
		return transactionManager;

	}
	*/
	
}









