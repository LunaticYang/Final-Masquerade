package com.nucleus.nsbt.brd4.spring.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class LoginController 
{

	
//Give Login Page
	@GetMapping("/showLoginPage")
	public String showLoginPage() 
	{
		return "login";	
	}
	

//for Login Error	
	@GetMapping("/access-denied")
	public String showAccessDeniedPage() 
	{	
		return "access-denied";	
	}
	
}









