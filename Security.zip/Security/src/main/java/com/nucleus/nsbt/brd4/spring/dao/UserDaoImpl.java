package com.nucleus.nsbt.brd4.spring.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.nucleus.nsbt.brd4.spring.entity.User;

@Repository
public class UserDaoImpl implements UserDao
{
	
	@Autowired
	SessionFactory sessionFactory;

	
	//Save Added Record
		@Override
		public void saveUser(User theUser) 
		{
			Session session = sessionFactory.getCurrentSession();
			session.save(theUser);
		}
		
		
		
		public List<User> getUsers()
		{
			Session session = sessionFactory.getCurrentSession();
			Query theQuery = session.createQuery("from user");
			
			@SuppressWarnings("unchecked")
			List<User> theUsers = theQuery.list();
			
			return theUsers;
		}
	
}