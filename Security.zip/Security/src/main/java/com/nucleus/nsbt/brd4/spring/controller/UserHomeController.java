package com.nucleus.nsbt.brd4.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestParam;

import com.nucleus.nsbt.brd4.spring.entity.Customer;
//import com.nucleus.nsbt.brd4.spring.service.CustomerService;

@Controller
public class UserHomeController 
{
	
	/*@Autowired
	private CustomerService customerService;*/

	@GetMapping("/user-Screen")
	public String showHome() 
	{		
		return "user-screen";
	}
	
	
	//----------------------------------------------------------------------------------------ADD
	//Left Screen Action
	@GetMapping("/addRecord")
	public String showAddForm(Model theModel) 
	{		
	
		Customer theCustomer = new Customer();
		theModel.addAttribute("THE_CUSTOMER",theCustomer);
		
		return "add-record-form";
	}
	

	@PostMapping("/saveAddedRecord")
	public String saveRecord( @ModelAttribute("THE_CUSTOMER") Customer theCustomer)  
	{		
		/*String registrationDate = new java.util.Date().toString();
		String modifiedDate = "-";
				
		theCustomer.setRegistrationDate(registrationDate);		
		theCustomer.setModifiedDate(modifiedDate);		
		
		customerService.saveCustomer(theCustomer);*/
		
		return "redirect:/addRecord";
	}
	
	
	
	//-----------------------------------------------------------------------------------------VIEW
	//Right Screen Action
	@GetMapping("/viewRecords")
	public String showRecords(/*Model theModel*/) 
	{		
	/*	List<Customer> theCustomers = customerService.getCustomers();
		
		theModel.addAttribute("THE_CUSTOMERS", theCustomers);*/
		
		return "view-all-records";
	}
	
	
	
	
	//-------------------------------------------------------------------------------------------SINGLE VIEW
	@GetMapping("/searchRecordId")
	public String viewRecordOf() 
	{		
		return "search-id";
	}
	
	@GetMapping("/viewRecord")
	public String viewRecord(/*@RequestParam("customerCode") int theId, Model theModel*/) 
	{		
		/*Customer theCustomer = customerService.getCustomer(theId);
		
		theModel.addAttribute("THE_CUSTOMER", theCustomer);*/
		return "redirect:/view-all-records";
	}
	
	
	
	
	//--------------------------------------------------------------------------------------------UPDATE
	@GetMapping("/updateRecordId")
	public String showSearchUpdate() 
	{		
		return "update-search-id";
	}
	
	
	@GetMapping("/updateRecord")
	public String showUpdateForm(/*@RequestParam("customerCode") int theId, Model theModel*/) 
	{		
		/*Customer theCustomer = customerService.getCustomer(theId);
		theModel.addAttribute("THE_CUSTOMER", theCustomer);*/
		
		return "update-record-form";
	}
	
	@GetMapping("/saveUpdate")
	public String updateRecord(@ModelAttribute("THE_CUSTOMER") Customer theCustomer) 
	{		
		
		String modifiedDate = new java.util.Date().toString();
		theCustomer.setModifiedDate(modifiedDate);
		
		/*customerService.updateCustomer(theCustomer);*/
		return "redirect:/viewRecords";
	}
	
	

	
	//----------------------------------------------------------------------------------------------Delete
	@GetMapping("/deleteRecordId")
	public String showDelete() 
	{		
		return "delete-search-id";
	}
	
	
	@GetMapping("/deleteRecord")
	public String deleteRecord(/*@RequestParam("customerCode") int theId*/) 
	{		
		/*customerService.deleteCustomer(theId);*/
		
		return "redirect:/viewRecords";
	}

}