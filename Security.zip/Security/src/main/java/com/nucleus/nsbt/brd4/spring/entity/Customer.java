package com.nucleus.nsbt.brd4.spring.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Table;


@Entity
@Table(name="Customer_18060163")
public class Customer 
{
 
//Fields-----------------------------------------------------------------------------------------
	
	
	@Column(name="customer_code")
	private int customerCode;
 
	@Column(name="customer_name")
	private String customerName;
	
	@Column(name="customer_address")
	private String customerAddress;
	
	@Column(name="customer_pincode")
	private String customerPinCode;
	
	@Column(name="customer_email")
	private String customerEmail;
	
	@Column(name="customer_contact_number")
	private String customerContactNumber;
	
	
	@Column(name="registration_date")
	private String registrationDate;
	
	@Column(name="created_by")
	private String createdBy;
	
	@Column(name="modified_date")
	private String modifiedDate;

	
	
	
	
//Getters------------------------------------------------------------------------------------------------

	
	public int getCustomerCode() {
		return customerCode;
	}

	public String getCustomerName() {
		return customerName;
	}

	public String getCustomerAddress() {
		return customerAddress;
	}

	public String getCustomerPinCode() {
		return customerPinCode;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public String getCustomerContactNumber() {
		return customerContactNumber;
	}

	public String getRegistrationDate() {
		return registrationDate;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public String getModifiedDate() {
		return modifiedDate;
	}

	
	
	
//Setters------------------------------------------------------------------------------------------

	
	public void setCustomerCode(int customerCode) {
		this.customerCode = customerCode;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public void setCustomerAddress(String customerAddress) {
		this.customerAddress = customerAddress;
	}

	public void setCustomerPinCode(String customerPinCode) {
		this.customerPinCode = customerPinCode;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	public void setCustomerContactNumber(String customerContactNumber) {
		this.customerContactNumber = customerContactNumber;
	}

	public void setRegistrationDate(String registrationDate) {
		this.registrationDate = registrationDate;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public void setModifiedDate(String modifiedDate) {
		this.modifiedDate = modifiedDate;
	}

	
	
	
	
//To String---------------------------------------------------------------------------------------------------
	@Override
	public String toString() 
	{
		return "Customer [customerCode=" + customerCode + ", customerName=" + customerName + ", customerAddress="
				+ customerAddress + ", customerPinCode=" + customerPinCode + ", customerEmail=" + customerEmail
				+ ", customerContactNumber=" + customerContactNumber + ", registrationDate=" + registrationDate
				+ ", createdBy=" + createdBy + ", modifiedDate=" + modifiedDate + "]";
	}
	
	
	
	

	
	
	
}
