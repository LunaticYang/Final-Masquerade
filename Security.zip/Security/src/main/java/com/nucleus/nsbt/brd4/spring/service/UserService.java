package com.nucleus.nsbt.brd4.spring.service;

import java.util.List;

import com.nucleus.nsbt.brd4.spring.entity.User;

public interface UserService 
{

	public List<User> getUsers();
	
	public void saveUser(User theUser);
	
}
