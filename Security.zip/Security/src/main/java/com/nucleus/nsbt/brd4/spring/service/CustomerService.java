package com.nucleus.nsbt.brd4.spring.service;

import java.util.List;

import com.nucleus.nsbt.brd4.spring.entity.Customer;

public interface CustomerService 
{
	  
	  public void saveCustomer(Customer theCustomer);
	
	  public List<Customer> getCustomers();
  
	  public Customer getCustomer(int theId);
  
	  public void updateCustomer(Customer theCustomer);

	  public void deleteCustomer(int theId);
  
  
}
