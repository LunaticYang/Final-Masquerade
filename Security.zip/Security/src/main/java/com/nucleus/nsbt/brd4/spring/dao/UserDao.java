package com.nucleus.nsbt.brd4.spring.dao;

import java.util.List;

import com.nucleus.nsbt.brd4.spring.entity.User;

public interface UserDao 
{
    public List<User> getUsers();
    
    public void saveUser(User theUser);
}
