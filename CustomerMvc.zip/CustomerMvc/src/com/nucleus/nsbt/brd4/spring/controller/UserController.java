package com.nucleus.nsbt.brd4.spring.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.nucleus.nsbt.brd4.spring.entity.Customer;
import com.nucleus.nsbt.brd4.spring.service.CustomerService;




@Controller("/user")
public class UserController
{

	
	@Autowired
	private CustomerService customerService;
	
	
	
//ADD---------------------------------------------------------------------------------
	
	@GetMapping("/addRecord")
	public String showAddForm(Model theModel)
	{
		
		Customer theCustomer = new Customer();
				
		theModel.addAttribute("THE_CUSTOMER", theCustomer);
		
		return "add-record-form";
	}
	
	
	@PostMapping("/saveRecord")
	public String saveRecord(@ModelAttribute("THE_CUSTOMER") Customer theCustomer)
	{
	    
		String registrationDate = new java.util.Date().toString();
		String modifiedDate = "-";
				
		theCustomer.setRegistrationDate(registrationDate);		
		theCustomer.setModifiedDate(modifiedDate);		
				
		customerService.saveCustomer(theCustomer);
		
		return "redirect:/user/listRecords";
	}
	
	
//View All-----------------------------------------------------------------------------	
	
	@PostMapping("/listRecords")
	public String listRecords(Model theModel)
	{
		List<Customer> customers = customerService.getCustomers();					
		theModel.addAttribute("CUSTOMERS", customers);
		
		return "view-all-records";
	}
	
	
//Update---------------------------------------------------------------------------------	
	
	@GetMapping("/updateRecord")
	public String upadateId()
	{
		return "update-search-id";
	}
	
	
	@GetMapping("/updateForm")
	public String showUpdateForm(@RequestParam("customerId") int theId,Model theModel)
	{
		
		Customer theCustomer = customerService.getCustomer(theId);
		theModel.addAttribute("THE_CUSTOMER", theCustomer);
		
		return "update-record-form";
	}
	
	
	@PostMapping("/saveUpdate")
	public String saveUpdate(@ModelAttribute("THE_CUSTOMER") Customer theCustomer)
	{
		
		String modifiedDate = new java.util.Date().toString();
		theCustomer.setModifiedDate(modifiedDate);
		
		customerService.updateCustomer(theCustomer);
		
		return "redirect:/user/listRecords";
	
	}
	
	
	
	
//Delete--------------------------------------------------------------------------------------	
	@GetMapping("/deleteRecord")
	public String deleteId()
	{
		return "delete-search-id";
	}
	
	
	@PostMapping("/deleteRecord")
	public String delete(@RequestParam("customerId") int theId)
	{
		customerService.deleteCustomer(theId);
		
		return "redirect:/user/listRecords";
	}
	
	
	
//Single View----------------------------------------------------------------------------------	
	@GetMapping("/viewRecord")
	public String searchId()
	{
		return "search-id";
	}
	
	
	@PostMapping("/search")
	public String search(@RequestParam("customerId") int theId, Model theModel)
	{
		Customer theCustomer = customerService.getCustomer(theId);
		theModel.addAttribute("THE_CUSTOMER", theCustomer);
		return "single-view";
	}
	
}
