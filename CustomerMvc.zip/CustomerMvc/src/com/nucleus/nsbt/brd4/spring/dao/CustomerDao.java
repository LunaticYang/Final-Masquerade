package com.nucleus.nsbt.brd4.spring.dao;

import java.util.List;

import com.nucleus.nsbt.brd4.spring.entity.Customer;

public interface CustomerDao 
{
	public List<Customer> getCustomers();

	public void saveCustomer(Customer theCustomer);

	public Customer getCustomer(int theId);

	public void deleteCustomer(int theId);

	public void updateCustomer(Customer theCustomer);
}
